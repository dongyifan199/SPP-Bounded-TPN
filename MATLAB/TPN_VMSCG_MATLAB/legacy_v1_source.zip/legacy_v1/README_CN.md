# TPN / V-MSCG MATLAB 工程

本工程实现截图中的两部分：

1. 强语义、single-server、enabling-memory TPN 的 state-class evolution；
2. 完整 V-MSCG 的构造、候选策略剪枝、secret path 枚举与 time-validity 验证。

主程序是 `run_example2.m`。它应复现论文示例的完整 V-MSCG（40 个顶点、42 条边），并验证：

- `T_pl={t2}` 是 time-valid；
- `T_pl={t3}` 不是 time-valid；
- 两个 pruned V-MSCG 各有 5 条到 secret vertex 的路径。

## 运行环境

- MATLAB R2020b 或更新版本；
- Optimization Toolbox（使用 `linprog`）；
- 不需要 Symbolic Math Toolbox。

在 MATLAB 中把当前文件夹切换到本工程根目录，然后运行：

```matlab
run_example2
```

完整回归测试：

```matlab
addpath('tests')
run_all_tests
```

结果将写入 `output/`：完整图及两个 pruned 图的 vertex/edge CSV 表和 PNG。

## 为什么没有把 Theta 简化成独立数值区间

代码对所有 firing-delay variables 保存一个混合开/闭线性域

```text
A * Delta <= b
```

并另存哪些行实际上是严格不等式。持续使能变迁的 age、每个有限 validity clock 都是 `Delta` 的仿射表达式。这样能保留不同变迁剩余 firing times 之间由同一个 delay 产生的相关性，避免“只保留各自上下界”造成伪路径。

严格不等式的可行性通过最大化公共正 slack 来判断；所有超时比较使用 `opts.tolerance`。若参数尺度特别大或特别小，应相应调整 `strictSlack` 和 `tolerance`。

## 文件结构

- `models/example2_tpn.m`：示例数据，也是新增模型的模板；
- `+vmscg/state_class_evolution.m`：Algorithm 1；
- `+vmscg/build.m`：Algorithm 2；
- `+vmscg/prune_policy.m`：Definition 3 的剪枝；
- `+vmscg/verify_policy.m`：逐 secret path 的 LP 验证；
- `run_parameter_sweep.m`：数值参数扫描模板；
- `tests/run_all_tests.m`：回归测试。

## 新增一个数值参数化 TPN

复制 `models/example2_tpn.m`，修改 `Pre`、`Post`、`M0`、`lower`、`upper` 和保护数据即可。矩阵约定为：place 对应行、transition 对应列；secret markings 按列存储。

`run_parameter_sweep.m` 展示了让同一个模型函数接收参数结构，并批量重建 V-MSCG 的方式。这属于“给定每组参数值后进行精确数值分析”。如果你后续所说的参数化 TPN 是指区间端点本身保留符号参数、希望一次性求出参数区域，本工程尚未实现 parametric polyhedron；那需要把 `linprog` 层替换成参数多面体运算，理论与代码都应另行扩展。

## 已明确的建模与论文细节

1. 根据 Fig. 1、轨迹和后继 marking，`t3` 的输入为 `p3+p6`，输出为 `p3`。因此它消耗 `p6`，同时重新使能 `t2`。
2. 所有给定 firing intervals 都按 `[l,u)` 处理，上端点是严格的。
3. `New(M,t)` 按文中 single-server/enabling-memory 定义实现：若被触发的 transition 在后继 marking 仍使能，它被视为 newly enabled；由 firing 新激活的其他 transition 也重置 age。
4. Fig. 2 中 `z21` 与 `z28` 的打印四元组相同，但图中保留为两个顶点。`paper-symbolic` 等价模式把“值为 0 的 validity clock 的最近 reset 来源”作为隐藏 symbolic provenance，因此能够复现 40/42 的编号与规模。若修订稿准备采用纯四元组相等，应重新讨论这两个顶点是否应合并。
5. time-validity 验证没有采用 big-M MILP，而是枚举终点处哪些 active protections 仍有效并解 LP。优点是没有 big-M 数值风险；代价是每条 path 最坏需要 `2^|T_pl|` 个 LP。保护变迁很多时可再替换为经过界限证明的 MILP。

## 当前适用边界

示例以及有限 V-MSCG 可直接处理。对于含循环的较大 TPN，终止性依赖论文中的 boundedness、A2（`T0` 中无 repetitive executable sequence）及规范化 augmented-state equivalence。当前 `paper-symbolic` 模式忠实于示例的 symbolic provenance；在把它用于一般循环模型前，建议先把修订稿最终采用的 canonical equivalence 明确定义下来，再把该等价判定写入 `state_signature.m`。

