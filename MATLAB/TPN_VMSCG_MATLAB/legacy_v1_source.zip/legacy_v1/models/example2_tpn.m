function G = example2_tpn(par)
%EXAMPLE2_TPN TPN and SPP data in Examples 1--4 of the manuscript.
% Optional fields in par override numerical data, e.g.:
%   G = example2_tpn(struct('timeout_t2', 10, 'I_t4', [2 7]));

if nargin == 0, par = struct(); end

G.name = 'High-risk equipment activation (Example 2)';
G.placeNames = {'p1','p2','p3','p4','p5','p6'};
G.transitionNames = {'t1','t2','t3','t4'};

% Rows are places p1,...,p6; columns are transitions t1,...,t4.
% t3 consumes p3+p6 and returns p3. Hence it removes the p6 token while
% re-enabling t2, exactly as in Fig. 1 and the stated markings.
G.Pre = [1 0 0 0;  ... % p1
         0 0 0 1;  ... % p2
         0 1 1 0;  ... % p3
         0 0 0 1;  ... % p4
         0 0 0 0;  ... % p5
         0 0 1 0];     % p6
G.Post = [0 0 0 0; ... % p1
          1 0 0 0; ... % p2
          0 0 1 0; ... % p3
          0 1 0 0; ... % p4
          0 0 0 1; ... % p5
          0 0 0 0];    % p6
G.M0 = [1;0;1;0;0;1];

G.lower = [2;1;2;3];
G.upper = [6;5;3.5;6]; % all upper endpoints are open
if isfield(par, 'I_t1'), G.lower(1)=par.I_t1(1); G.upper(1)=par.I_t1(2); end
if isfield(par, 'I_t2'), G.lower(2)=par.I_t2(1); G.upper(2)=par.I_t2(2); end
if isfield(par, 'I_t3'), G.lower(3)=par.I_t3(1); G.upper(3)=par.I_t3(2); end
if isfield(par, 'I_t4'), G.lower(4)=par.I_t4(1); G.upper(4)=par.I_t4(2); end

G.protectable = [false true true false];
G.timeout = [Inf 12 15 Inf];
G.gamma = [0 1 1 0];
G.cost = [0 2 3 0];
if isfield(par, 'timeout_t2'), G.timeout(2) = par.timeout_t2; end
if isfield(par, 'timeout_t3'), G.timeout(3) = par.timeout_t3; end

% Secret markings are column vectors: p5+p6 and p5.
G.secretMarkings = [0 0; 0 0; 0 0; 0 0; 1 1; 1 0];
G.secretRequirement = [1 1];

G.nP = size(G.Pre,1);
G.nT = size(G.Pre,2);
end

