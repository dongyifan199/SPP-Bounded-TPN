%% RUN_EXAMPLE2 Reproduce Examples 1--4 from the manuscript.
% Run this file from the project root. It constructs the complete V-MSCG,
% prunes it for T_pl={t2} and T_pl={t3}, and verifies both policies.

clear; clc;
root = fileparts(mfilename('fullpath'));
addpath(root, fullfile(root, 'models'));

G = example2_tpn();
opts = vmscg.default_options();
opts.verbose = true;
opts.equivalence = 'paper-symbolic';

fprintf('Building the complete V-MSCG ...\n');
GV = vmscg.build(G, opts);
fprintf('Complete V-MSCG: %d vertices, %d edges.\n', ...
    numel(GV.vertices), numel(GV.edges));

% The appendix/figure supplied with the example contains z0,...,z39 and
% e1,...,e42. These checks deliberately fail if a future edit changes it.
assert(numel(GV.vertices) == 40, ...
    'Expected 40 vertices (z0--z39) for the manuscript example.');
assert(numel(GV.edges) == 42, ...
    'Expected 42 edges (e1--e42) for the manuscript example.');

policyT2 = false(1, G.nT); policyT2(2) = true;
policyT3 = false(1, G.nT); policyT3(3) = true;

GP2 = vmscg.prune_policy(GV, policyT2);
GP3 = vmscg.prune_policy(GV, policyT3);

fprintf('Pruned graph for T_pl={t2}: %d vertices, %d edges.\n', ...
    numel(GP2.vertexIds), numel(GP2.edgeIds));
fprintf('Pruned graph for T_pl={t3}: %d vertices, %d edges.\n', ...
    numel(GP3.vertexIds), numel(GP3.edgeIds));

R2 = vmscg.verify_policy(G, GV, GP2, policyT2, opts);
R3 = vmscg.verify_policy(G, GV, GP3, policyT3, opts);

fprintf('T_pl={t2}: time-valid = %d, checked secret paths = %d.\n', ...
    R2.timeValid, R2.numSecretPaths);
fprintf('T_pl={t3}: time-valid = %d, checked secret paths = %d.\n', ...
    R3.timeValid, R3.numSecretPaths);
assert(R2.timeValid, 'The manuscript states that {t2} is time-valid.');
assert(~R3.timeValid, 'The manuscript states that {t3} is not time-valid.');

outDir = fullfile(root, 'output');
if ~exist(outDir, 'dir'), mkdir(outDir); end
vmscg.export_graph(G, GV, fullfile(outDir, 'complete'));
vmscg.export_graph(G, GV, fullfile(outDir, 'policy_t2'), GP2);
vmscg.export_graph(G, GV, fullfile(outDir, 'policy_t3'), GP3);

fprintf('\nDone. CSV tables and graph images are in:\n  %s\n', outDir);

