%% RUN_PARAMETER_SWEEP Example of repeated numerical parameter studies.
% This is a template for later parameterized examples. Each parameter tuple
% creates an ordinary numerical TPN; the same construction engine is reused.

clear; clc;
root = fileparts(mfilename('fullpath'));
addpath(root, fullfile(root, 'models'));

t2Timeouts = [8 10 12 14 16];
summary = table('Size', [numel(t2Timeouts), 5], ...
    'VariableTypes', {'double','double','double','double','logical'}, ...
    'VariableNames', {'timeout_t2','numVertices','numEdges','numSecretPaths','timeValid'});

opts = vmscg.default_options();
opts.verbose = false;
for k = 1:numel(t2Timeouts)
    par = struct('timeout_t2', t2Timeouts(k));
    G = example2_tpn(par);
    GV = vmscg.build(G, opts);
    policy = false(1, G.nT); policy(2) = true;
    GP = vmscg.prune_policy(GV, policy);
    R = vmscg.verify_policy(G, GV, GP, policy, opts);
    summary{k,:} = {t2Timeouts(k), numel(GV.vertices), numel(GV.edges), ...
        R.numSecretPaths, R.timeValid};
end

disp(summary);
if ~exist(fullfile(root,'output'),'dir'), mkdir(fullfile(root,'output')); end
writetable(summary, fullfile(root, 'output', 'parameter_sweep.csv'));
