function run_all_tests()
%RUN_ALL_TESTS Regression and semantic checks.
root=fileparts(fileparts(mfilename('fullpath')));
addpath(root,fullfile(root,'models'));
opts=vmscg.default_options(); opts.verbose=false;
G=example2_tpn();
vmscg.validate_model(G);

assert(isequal(find(vmscg.enabled_transitions(G,G.M0)),[1 2 3]));
GV=vmscg.build(G,opts);
assert(numel(GV.vertices)==40);
assert(numel(GV.edges)==42);

% Algorithm 1: firing t1 first must have Delta in [2,3.5).
S=GV.vertices(1);
[~,ei,ok]=vmscg.state_class_evolution(G,S,1,0,opts);
assert(ok && strcmp(ei.lowerText,'2'));
assert(contains(ei.upperText,'3.5'));

p2=false(1,G.nT);p2(2)=true;
p3=false(1,G.nT);p3(3)=true;
GP2=vmscg.prune_policy(GV,p2); GP3=vmscg.prune_policy(GV,p3);
R2=vmscg.verify_policy(G,GV,GP2,p2,opts);
R3=vmscg.verify_policy(G,GV,GP3,p3,opts);
assert(R2.timeValid && R2.numSecretPaths==5);
assert(~R3.timeValid && R3.numSecretPaths==5);

fprintf('All V-MSCG tests passed.\n');
end

