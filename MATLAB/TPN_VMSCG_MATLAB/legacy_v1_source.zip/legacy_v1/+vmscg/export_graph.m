function export_graph(G,GV,prefix,GP)
%EXPORT_GRAPH Write readable vertex/edge CSV files and a PNG graph.
if nargin<4
    vertexIds=[GV.vertices.id]; edgeIds=1:numel(GV.edges);
else
    vertexIds=GP.vertexIds; edgeIds=GP.edgeIds;
end

nv=numel(vertexIds);
vid=zeros(nv,1); marking=strings(nv,1); rho=strings(nv,1);
theta=strings(nv,1); nu=strings(nv,1); secret=false(nv,1);
for k=1:nv
    S=GV.vertices(vertexIds(k)+1); vid(k)=S.id;
    marking(k)=marking_text(G,S.M); rho(k)=string(S.rho(G.protectable));
    theta(k)=theta_text(G,S); nu(k)=nu_text(G,S);
    secret(k)=vmscg.secret_requirement(G,S.M);
end
VT=table(vid,marking,theta,rho,nu,secret, ...
    'VariableNames',{'vertex','marking','Theta','rho','nu','isSecret'});
writetable(VT,[prefix '_vertices.csv']);

ne=numel(edgeIds); eid=zeros(ne,1); source=zeros(ne,1); target=zeros(ne,1);
transition=strings(ne,1); kappa=zeros(ne,1); delta=strings(ne,1);
delayDomain=strings(ne,1);
for k=1:ne
    e=GV.edges(edgeIds(k)); eid(k)=e.id; source(k)=e.source; target(k)=e.target;
    transition(k)=string(G.transitionNames{e.transition}); kappa(k)=e.kappa;
    delta(k)=string(e.deltaName);
    delayDomain(k)=sprintf('[%s,%s)',e.lowerText,e.upperText);
end
ET=table(eid,source,target,transition,delta,kappa,delayDomain, ...
    'VariableNames',{'edge','source','target','transition','Delta','kappa','domain'});
writetable(ET,[prefix '_edges.csv']);

if ne>0
    local=zeros(1,max(vertexIds)+1);
    for k=1:numel(vertexIds),local(vertexIds(k)+1)=k;end
    d=digraph(local(source+1),local(target+1),[],nv);
    f=figure('Visible','off','Color','w','Position',[100 100 1200 650]);
    p=plot(d,'Layout','layered','Direction','right','NodeLabel', ...
        compose('z%d',vertexIds),'ArrowSize',8,'LineWidth',0.8);
    p.EdgeLabel=compose('e%d',eid);
    title(strrep(G.name,'_','\_'));
    try, exportgraphics(f,[prefix '_graph.png'],'Resolution',180);
    catch, saveas(f,[prefix '_graph.png']); end
    close(f);
end
end

function txt=marking_text(G,M)
z={};
for p=find(M(:)'>0)
    if M(p)==1,z{end+1}=G.placeNames{p}; %#ok<AGROW>
    else,z{end+1}=sprintf('%g%s',M(p),G.placeNames{p});end %#ok<AGROW>
end
if isempty(z),txt="0";else,txt=string(strjoin(z,'+'));end
end

function txt=theta_text(G,S)
z={};
for t=find(S.enabled)
    a=vmscg.expr_to_text(S.age{t},S.varLabels);
    if strcmp(a,'0')
        z{end+1}=sprintf('%g<=theta_%d<%g',G.lower(t),t,G.upper(t)); %#ok<AGROW>
    else
        z{end+1}=sprintf('max(0,%g-(%s))<=theta_%d<%g-(%s)', ...
            G.lower(t),a,t,G.upper(t),a); %#ok<AGROW>
    end
end
txt=string(strjoin(z,'; '));
end

function txt=nu_text(G,S)
z={};
for t=find(G.protectable)
    if S.nuActive(t),value=vmscg.expr_to_text(S.nu{t},S.varLabels);
    else,value='Inf';end
    z{end+1}=sprintf('nu_%d=%s',t,value); %#ok<AGROW>
end
txt=string(strjoin(z,'; '));
end
