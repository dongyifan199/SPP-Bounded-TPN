function GP = prune_policy(GV, policy)
%PRUNE_POLICY Apply Definition 3 and retain only reachable vertices.
G=GV.model;
assert(islogical(policy) && numel(policy)==G.nT, ...
    'policy must be a logical vector of length nT.');
assert(~any(policy & ~G.protectable), ...
    'A policy may contain only protectable transitions.');

keep=false(1,numel(GV.edges));
for k=1:numel(GV.edges)
    e=GV.edges(k); t=e.transition;
    keep(k)=(~G.protectable(t) && e.kappa==0) || ...
        (policy(t) && e.kappa==1) || (~policy(t) && G.protectable(t) && e.kappa==2);
end

reachable=false(1,numel(GV.vertices)); reachable(1)=true;
changed=true;
while changed
    changed=false;
    for k=find(keep)
        e=GV.edges(k);
        if reachable(e.source+1) && ~reachable(e.target+1)
            reachable(e.target+1)=true; changed=true;
        end
    end
end
keep=keep & arrayfun(@(e)reachable(e.source+1)&&reachable(e.target+1),GV.edges);
GP.policy=policy;
GP.vertexIds=find(reachable)-1;
GP.edgeIds=find(keep);
GP.initialVertex=0;
end

