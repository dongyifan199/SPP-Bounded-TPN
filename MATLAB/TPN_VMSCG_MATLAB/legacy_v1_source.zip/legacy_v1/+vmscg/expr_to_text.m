function txt = expr_to_text(coeff, labels)
%EXPR_TO_TEXT Human-readable sum of symbolic delay variables.
idx = find(abs(coeff)>1e-12);
if isempty(idx), txt='0'; return; end
parts = cell(1,numel(idx));
for k=1:numel(idx)
    c=coeff(idx(k)); name=labels{idx(k)};
    if abs(c-1)<1e-12, parts{k}=name;
    else, parts{k}=sprintf('%g*%s',c,name); end
end
txt = strjoin(parts,'+');
end

