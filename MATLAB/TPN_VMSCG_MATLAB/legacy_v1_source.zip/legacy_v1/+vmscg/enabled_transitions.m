function en = enabled_transitions(G, M)
%ENABLED_TRANSITIONS Logical row vector for En(M).
en = all(M(:) >= G.Pre, 1);
end

