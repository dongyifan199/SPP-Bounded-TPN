function paths = enumerate_secret_paths(G,GV,GP,maxPaths)
%ENUMERATE_SECRET_PATHS All vertex-simple initial-to-secret paths.
% A complete augmented V-MSCG cycle is not unfolded twice.
n=numel(GV.vertices);
adj=cell(1,n);
for k=GP.edgeIds
    e=GV.edges(k); adj{e.source+1}(end+1)=k; %#ok<AGROW>
end
paths={};
onPath=false(1,n);
dfs(0,zeros(1,0));

    function dfs(v,edgePath)
        onPath(v+1)=true;
        [secret,~]=vmscg.secret_requirement(G,GV.vertices(v+1).M);
        if secret
            paths{end+1}=edgePath; %#ok<AGROW>
            assert(numel(paths)<=maxPaths,'Maximum path limit reached.');
        end
        % Continue after a secret vertex as well: a later reachable secret
        % marking is a separate obligation under the SPP definition.
        for ee=adj{v+1}
            w=GV.edges(ee).target;
            if ~onPath(w+1), dfs(w,[edgePath ee]); end %#ok<AGROW>
        end
        onPath(v+1)=false;
    end
end
