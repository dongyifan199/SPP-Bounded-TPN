function tf = strict_feasible(domain, opts)
%STRICT_FEASIBLE Feasibility of mixed closed/strict linear inequalities.
% domain represents A*x <= b, with rows marked strict interpreted as <.
n = size(domain.A,2);
if n == 0
    lhs = zeros(size(domain.b));
    tf = all(lhs(~domain.strict) <= domain.b(~domain.strict) + opts.tolerance) && ...
         all(lhs(domain.strict) < domain.b(domain.strict) - opts.tolerance);
    return;
end

lpopt = optimoptions('linprog','Display','none');
if any(domain.strict)
    % A_i*x + epsilon <= b_i for strict rows. A common positive epsilon
    % exists iff the relative interior imposed by all strict rows is nonempty.
    Aaug = [domain.A, sparse(double(domain.strict(:)))];
    f = [zeros(n,1); -1];
    lb = [-inf(n,1); 0];
    ub = [ inf(n,1); 1];
    [x,~,flag] = linprog(f,Aaug,domain.b,[],[],lb,ub,lpopt);
    tf = flag > 0 && x(end) > opts.strictSlack;
else
    f = zeros(n,1);
    [~,~,flag] = linprog(f,domain.A,domain.b,[],[],[],[],lpopt);
    tf = flag > 0;
end
end
