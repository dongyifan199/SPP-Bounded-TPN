function key = state_signature(G,S,opts)
%STATE_SIGNATURE Equality key for a complete augmented symbolic class.
% The paper-symbolic key uses M, symbolic Theta, rho, and symbolic nu.

parts = {sprintf('M:%g,',S.M), ['rho:' S.rho]};
for t=find(S.enabled)
    parts{end+1}=sprintf('a%d:%s',t,expr_key(S.age{t},S.varLabels)); %#ok<AGROW>
end
for t=find(G.protectable)
    if ~S.nuActive(t)
        parts{end+1}=sprintf('v%d:Inf',t); %#ok<AGROW>
    else
        ek=expr_key(S.nu{t},S.varLabels);
        if strcmp(opts.equivalence,'paper-symbolic') && strcmp(ek,'0')
            % The printed graph distinguishes z21 and z28 although their
            % displayed tuples coincide. Keeping the reset origin captures
            % the hidden symbolic provenance and reproduces Fig. 2.
            ek=[ek '@' S.resetOrigin{t}];
        end
        parts{end+1}=sprintf('v%d:%s',t,ek); %#ok<AGROW>
    end
end
key=strjoin(parts,'|');
end

function out=expr_key(c,labels)
idx=find(abs(c)>1e-12);
if isempty(idx), out='0'; return; end
z=cell(1,numel(idx));
for k=1:numel(idx)
    z{k}=sprintf('%s*%.12g',labels{idx(k)},c(idx(k)));
end
out=strjoin(z,'+');
end

