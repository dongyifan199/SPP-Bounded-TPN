function GV = build(G, opts)
%BUILD Construct the complete V-MSCG (Algorithms 1 and 2).
% The implementation uses a FIFO worklist and a hash map for expected O(1)
% duplicate lookup. Symbolic constraints are stored as A*Delta <= b plus a
% strict-row mask, so correlations between firing delays are not discarded.

if nargin<2, opts=vmscg.default_options(); end
vmscg.validate_model(G);

S.M = G.M0(:);
S.enabled = vmscg.enabled_transitions(G,S.M);
S.age = cell(1,G.nT);
for t=find(S.enabled), S.age{t}=zeros(1,0); end
S.domain = struct('A',sparse(0,0),'b',zeros(0,1),'strict',false(0,1));
S.varLabels = cell(1,0);
S.rho = repmat('-',1,G.nT); S.rho(G.protectable)='U';
S.nu = cell(1,G.nT);
S.nuActive = false(1,G.nT);
S.resetOrigin = repmat({''},1,G.nT);
S.id = 0;

vertices = S;
edges = struct('id',{},'source',{},'target',{},'transition',{}, ...
    'kappa',{},'deltaName',{},'lowerText',{},'upperText',{});
seen = containers.Map('KeyType','char','ValueType','double');
seen(vmscg.state_signature(G,S,opts)) = 1;
open = zeros(1,opts.maxVertices); head=1; tail=1; open(1)=1;

while head<=tail
    sourceIndex=open(head); head=head+1;
    current=vertices(sourceIndex);
    for t=find(current.enabled)
        [base,edgeInfo,ok]=vmscg.state_class_evolution( ...
            G,current,t,current.id,opts);
        if ~ok, continue; end

        % Advance all finite validity clocks by the same firing delay.
        base.nu=current.nu;
        base.nuActive=current.nuActive;
        base.resetOrigin=current.resetOrigin;
        for p=find(G.protectable & current.nuActive)
            candidate=[current.nu{p},0]+edgeInfo.deltaCoeff;
            if vmscg.min_linear(base.domain,candidate) > ...
                    G.timeout(p)+opts.tolerance
                base.nuActive(p)=false; base.nu{p}=[];
                base.resetOrigin{p}='';
            else
                base.nu{p}=candidate;
            end
        end

        if ~G.protectable(t)
            branches=make_branch(base,t,base.rho(t),0,edgeInfo.deltaName);
        elseif current.rho(t)=='U'
            y=make_branch(base,t,'Y',1,edgeInfo.deltaName);
            n=make_branch(base,t,'N',2,edgeInfo.deltaName);
            branches=[y n];
        elseif current.rho(t)=='Y'
            branches=make_branch(base,t,'Y',1,edgeInfo.deltaName);
        else
            branches=make_branch(base,t,'N',2,edgeInfo.deltaName);
        end

        for q=1:numel(branches)
            next=base;
            next.rho=branches(q).rho;
            next.nu=branches(q).nu;
            next.nuActive=branches(q).nuActive;
            next.resetOrigin=branches(q).resetOrigin;
            key=vmscg.state_signature(G,next,opts);
            if isKey(seen,key)
                targetIndex=seen(key);
            else
                assert(numel(vertices)<opts.maxVertices, ...
                    'Maximum vertex limit (%d) reached.',opts.maxVertices);
                next.id=numel(vertices); % public IDs are z0,z1,...
                vertices(end+1)=next; %#ok<AGROW>
                targetIndex=numel(vertices);
                seen(key)=targetIndex;
                tail=tail+1; open(tail)=targetIndex;
            end
            e.id=numel(edges)+1;
            e.source=current.id;
            e.target=vertices(targetIndex).id;
            e.transition=t;
            e.kappa=branches(q).kappa;
            e.deltaName=edgeInfo.deltaName;
            e.lowerText=edgeInfo.lowerText;
            e.upperText=edgeInfo.upperText;
            edges(end+1)=e; %#ok<AGROW>
        end
    end
    if opts.verbose && mod(head,100)==0
        fprintf('  explored %d, discovered %d vertices\n',head-1,numel(vertices));
    end
end

GV.model=G;
GV.vertices=vertices;
GV.edges=edges;
GV.initialVertex=0;
GV.options=opts;
end

function b=make_branch(base,t,status,kappa,deltaName)
b.rho=base.rho; b.rho(t)=status;
b.nu=base.nu; b.nuActive=base.nuActive;
b.resetOrigin=base.resetOrigin;
b.kappa=kappa;
if status=='Y'
    b.nuActive(t)=true;
    b.nu{t}=zeros(1,numel(base.varLabels));
    b.resetOrigin{t}=deltaName;
end
end
