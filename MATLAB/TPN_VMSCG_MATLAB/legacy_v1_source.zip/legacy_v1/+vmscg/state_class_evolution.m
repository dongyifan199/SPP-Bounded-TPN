function [S2, edgeInfo, feasible] = state_class_evolution(G, S, t, sourceId, opts)
%STATE_CLASS_EVOLUTION Exact constrained implementation of Algorithm 1.
% Clocks are represented by their elapsed ages. Each age is an affine sum
% of symbolic firing delays. The path domain retains all correlations.

en = S.enabled;
assert(en(t), 'Transition t%d is not enabled.', t);
n = numel(S.varLabels);
e = zeros(1,n+1); e(end) = 1;

domain.A = [S.domain.A, sparse(size(S.domain.A,1),1)];
domain.b = S.domain.b;
domain.strict = S.domain.strict;

% delta >= 0.
domain = append_row(domain, -e, 0, false);
% The fired transition must have reached its lower bound:
% age(t)+delta >= lower(t).
firingAge = [S.age{t},0] + e;
domain = append_row(domain, -firingAge, -G.lower(t), false);
% Strong semantics: no enabled transition reaches its open upper bound.
for s = find(en)
    ageAtFire = [S.age{s},0] + e;
    domain = append_row(domain, ageAtFire, G.upper(s), true);
end

feasible = vmscg.strict_feasible(domain, opts);
S2 = []; edgeInfo = [];
if ~feasible, return; end

Mminus = S.M - G.Pre(:,t);
M2 = Mminus + G.Post(:,t);
en2 = vmscg.enabled_transitions(G,M2);

age2 = cell(1,G.nT);
newly = false(1,G.nT);
for s = find(en2)
    % Enabling-memory, single-server New(M,t) rule in the manuscript.
    newly(s) = (s==t) || ...
        (~all(Mminus >= G.Pre(:,s)) && all(M2 >= G.Pre(:,s)));
    if newly(s)
        age2{s} = zeros(1,n+1);
    else
        age2{s} = [S.age{s},0] + e;
    end
end

S2 = S;
S2.M = M2;
S2.enabled = en2;
S2.age = age2;
S2.domain = domain;
S2.varLabels = [S.varLabels, {sprintf('Delta_%d_%d',sourceId,t)}];

edgeInfo.transition = t;
edgeInfo.deltaCoeff = e;
edgeInfo.deltaName = S2.varLabels{end};
edgeInfo.newlyEnabled = newly;
edgeInfo.lowerText = delay_lower_text(G,S,t);
edgeInfo.upperText = delay_upper_text(G,S);
end

function D = append_row(D, a, b, isStrict)
D.A(end+1,:) = sparse(a);
D.b(end+1,1) = b;
D.strict(end+1,1) = logical(isStrict);
end

function txt = delay_lower_text(G,S,t)
a = vmscg.expr_to_text(S.age{t},S.varLabels);
if strcmp(a,'0')
    txt = sprintf('%g',G.lower(t));
else
    txt = sprintf('max(0,%g-(%s))',G.lower(t),a);
end
end

function txt = delay_upper_text(G,S)
parts = cell(1,nnz(S.enabled)); k = 0;
for s = find(S.enabled)
    k=k+1; a=vmscg.expr_to_text(S.age{s},S.varLabels);
    if strcmp(a,'0'), parts{k}=sprintf('%g',G.upper(s));
    else, parts{k}=sprintf('%g-(%s)',G.upper(s),a); end
end
if numel(parts)==1, txt=parts{1};
else, txt=['min(' strjoin(parts,',') ')']; end
end
