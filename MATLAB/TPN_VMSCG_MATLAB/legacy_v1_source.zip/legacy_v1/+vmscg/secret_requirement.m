function [isSecret,requirement] = secret_requirement(G,M)
%SECRET_REQUIREMENT Exact marking lookup for the finite example interface.
isSecret=false; requirement=0;
for k=1:size(G.secretMarkings,2)
    if isequal(M(:),G.secretMarkings(:,k))
        isSecret=true; requirement=G.secretRequirement(k); return;
    end
end
end

