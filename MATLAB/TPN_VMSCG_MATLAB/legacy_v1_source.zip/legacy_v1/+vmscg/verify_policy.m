function R = verify_policy(G,GV,GP,policy,opts)
%VERIFY_POLICY Check time validity on all vertex-simple secret paths.
% Instead of a big-M MILP, this implementation enumerates which active
% protected clocks are valid at the terminal secret marking and solves exact
% LP-feasibility subproblems. This avoids choosing an unsafe big-M constant.

paths=vmscg.enumerate_secret_paths(G,GV,GP,opts.maxPaths);
R.timeValid=true;
R.numSecretPaths=numel(paths);
R.paths=paths;
R.counterexample=[];

for q=1:numel(paths)
    edgeIds=paths{q};
    [S,transitions]=replay_path(G,GV,edgeIds,policy,opts);
    [isSecret,req]=vmscg.secret_requirement(G,S.M);
    assert(isSecret,'Internal error: path does not end at a secret marking.');

    active=find(policy & S.nuActive);
    for mask=0:(2^numel(active)-1)
        valid=false(1,G.nT);
        for j=1:numel(active), valid(active(j))=bitget(mask,j)>0; end
        if sum(G.gamma(valid)) >= req, continue; end

        D=S.domain;
        for t=active
            if valid(t)
                D=add_constraint(D,S.nu{t},G.timeout(t),false);
            else
                % nu(t) > timeout(t)  <=>  -nu(t) < -timeout(t).
                D=add_constraint(D,-S.nu{t},-G.timeout(t),true);
            end
        end
        if vmscg.strict_feasible(D,opts)
            R.timeValid=false;
            R.counterexample.pathNumber=q;
            R.counterexample.edgeIds=edgeIds;
            R.counterexample.transitions=transitions;
            R.counterexample.validProtectedTransitions=find(valid);
            R.counterexample.requirement=req;
            R.counterexample.clearance=sum(G.gamma(valid));
            return;
        end
    end
end
end

function [S,transitions]=replay_path(G,GV,edgeIds,policy,opts)
S.M=G.M0(:); S.enabled=vmscg.enabled_transitions(G,S.M);
S.age=cell(1,G.nT); for t=find(S.enabled),S.age{t}=zeros(1,0);end
S.domain=struct('A',sparse(0,0),'b',zeros(0,1),'strict',false(0,1));
S.varLabels=cell(1,0); S.rho=repmat('-',1,G.nT);
S.rho(G.protectable)='U'; S.nu=cell(1,G.nT);
S.nuActive=false(1,G.nT); S.resetOrigin=repmat({''},1,G.nT); S.id=0;
transitions=zeros(1,numel(edgeIds));

for k=1:numel(edgeIds)
    eGraph=GV.edges(edgeIds(k)); t=eGraph.transition; transitions(k)=t;
    [B,ei,ok]=vmscg.state_class_evolution(G,S,t,eGraph.source,opts);
    assert(ok,'A graph path became infeasible during independent replay.');
    B.nu=S.nu; B.nuActive=S.nuActive; B.resetOrigin=S.resetOrigin;
    for p=find(G.protectable & S.nuActive)
        cand=[S.nu{p},0]+ei.deltaCoeff;
        if vmscg.min_linear(B.domain,cand)>G.timeout(p)+opts.tolerance
            B.nuActive(p)=false; B.nu{p}=[]; B.resetOrigin{p}='';
        else
            B.nu{p}=cand;
        end
    end
    if G.protectable(t)
        if policy(t)
            B.rho(t)='Y'; B.nuActive(t)=true;
            B.nu{t}=zeros(1,numel(B.varLabels)); B.resetOrigin{t}=ei.deltaName;
        else
            B.rho(t)='N';
        end
    end
    S=B;
end
end

function D=add_constraint(D,a,b,isStrict)
D.A(end+1,:)=sparse(a); D.b(end+1,1)=b; D.strict(end+1,1)=logical(isStrict);
end
