function opts = default_options()
%DEFAULT_OPTIONS Numerical and exploration options.
opts.tolerance = 1e-9;
opts.strictSlack = 1e-8;
opts.maxVertices = 100000;
opts.maxPaths = 100000;
opts.verbose = false;
% paper-symbolic preserves the reset origin of a zero validity clock. This
% reproduces the 40-vertex/42-edge graph printed in the manuscript.
opts.equivalence = 'paper-symbolic';
end

