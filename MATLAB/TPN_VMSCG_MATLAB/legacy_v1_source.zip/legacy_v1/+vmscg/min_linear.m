function value = min_linear(domain, coeff)
%MIN_LINEAR Infimum of coeff*x over the closure of a strict polyhedron.
n = size(domain.A,2);
if n == 0, value = 0; return; end
lpopt = optimoptions('linprog','Display','none');
[~,value,flag] = linprog(coeff(:),domain.A,domain.b,[],[],[],[],lpopt);
assert(flag > 0, 'Internal error: minimization domain is infeasible.');
end

